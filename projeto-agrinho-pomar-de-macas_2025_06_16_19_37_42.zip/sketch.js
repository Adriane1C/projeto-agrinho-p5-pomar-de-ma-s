let orchard;

function setup() {
  createCanvas(700, 600);
  orchard = new Orchard(5); // Cria 5 árvores
}

function draw() {
  background(220);
  drawGround();

  orchard.update();
  orchard.display();

  fill(0);
  textSize(20);
  text("Clique para irrigar as árvores!", 10, 70);
  text("Árvores maduras produzirão maçãs!", 30, 50);
}

function mousePressed() {
  orchard.waterAll(); // Irriga todas as árvores ao clicar
}

function drawGround() {
  fill(34, 139, 34);
  rect(0, height - 150, width, 50);
}

// ---------- Pomar ----------
class Orchard {
  constructor(treeCount) {
    this.trees = [];
    for (let i = 0; i < treeCount; i++) {
      this.trees.push(new AppleTree(150 + i * 150, 450));
    }
  }

  update() {
    for (let tree of this.trees) tree.update();
  }

  display() {
    for (let tree of this.trees) tree.display();
  }

  waterAll() {
    for (let tree of this.trees) tree.water();
  }
}

// ---------- Árvore ----------
class AppleTree {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.minHeight = 50;
    this.maxHeight = 120;
    this.height = this.minHeight;
    this.age = 0;
    this.waterLevel = 100;
    this.apples = [];
    this.hasProducedApples = false;
  }

  update() {
    this.age++;

    // Crescimento gradual, mais rápido se bem irrigada
    if (this.waterLevel > 0 && this.height < this.maxHeight) {
      this.height += 0.1;
    }

    // Produz maçãs ao atingir altura máxima pela primeira vez
    if (this.height >= this.maxHeight && !this.hasProducedApples) {
      this.produceApples();
      this.hasProducedApples = true;
    }

    // Água diminui com o tempo
    this.waterLevel -= 0.06;
    if (this.waterLevel < 0) this.waterLevel = 0;

    // Se sem água, para de crescer
    if (this.waterLevel < 20 && this.height > this.minHeight) {
      this.height -= 0.02; // murcha lentamente
    }

    for (let apple of this.apples) {
      apple.update();
    }
  }

  display() {
    // Tronco
    fill(139, 69, 19);
    rect(this.x - 10, this.y - this.height, 20, this.height);

    // Folhas com tom variável
    let leafGreen = map(this.height, this.minHeight, this.maxHeight, 120, 60);
    fill(34, leafGreen, 34);
    noStroke();
    ellipse(this.x, this.y - this.height - 20, 80, 80);

    // Água
    fill(0);
    textSize(12);
    text("Água: " + Math.round(this.waterLevel), this.x - 20, this.y - this.height - 30);

    for (let apple of this.apples) {
      apple.display();
    }
  }

  water() {
    this.waterLevel += 1;
    if (this.waterLevel > 10) this.waterLevel = 100;
  }

  produceApples() {
    for (let i = 0; i < 5; i++) {
      let appleX = this.x - 25 + random(50);
      let appleY = this.y - this.height - random(30, 25);
      this.apples.push(new Apple(appleX, appleY));
    }
  }
}

// ---------- Maçã ----------
class Apple {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 15;
    this.color = color(255, 0, 0);
    this.speed = random(0.5, 1);
  }

  update() {
    if (this.y < height - 100) {
      this.y += this.speed;
    }
  }

  display() {
    fill(this.color);
    noStroke();
    ellipse(this.x, this.y, this.size, this.size);
  }
}

